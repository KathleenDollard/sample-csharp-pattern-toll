﻿namespace TollEngine
{
    public partial class TollCalculator
    {
        private enum TimeBand
        {
            MorningRush,
            Daytime,
            EveningRush,
            Overnight
        }

    }
}